//
//  Function.cpp
//  Assignment01
//
//  Created by Le Pham Nhat Quynh on 11/16/21.
//

#include "Function.h"
CFolder::CFolder():CItem(){
}
CFolder::CFolder(string Name):CItem(Name){
   
}
CFile::CFile():CItem(){
}
CItem::CItem(){
    name="Untitled";
    size=0;
}
CItem::CItem(string Name){
    name=Name;
    size=0;
}
CItem::CItem(string Name,int Size){
    name=Name;
    size=Size;
}
CFile::CFile(string Name,int Size):CItem(Name,Size){
    
}
void CFolder::add(CItem* item){
    s.push_back(item);
}
void CFolder::print(bool hidden){
    for (int i=0;i<s.size();i++)
    {
        if(hidden||!s[i]->getHidden()) s[i]->output();
    }
}
bool CItem::getHidden(){
    return hidden;
}
void CItem::output(){
    cout<<"-----\n";
    cout<<"Name: "<<name<<endl;
    cout<<"Size: "<<size<<endl;
}
