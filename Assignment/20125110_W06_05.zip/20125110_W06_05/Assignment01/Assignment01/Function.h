//
//  Function.hpp
//  Assignment01
//
//  Created by Le Pham Nhat Quynh on 11/16/21.
//

#ifndef Function_hpp
#define Function_hpp

#include <iostream>
#include <vector>
using namespace std;
class CItem{
private:
    string name;
    int size;
protected:
    bool hidden=false;
public:
    CItem();
    CItem(string Name,int Size);
    CItem(string Name);
    bool getHidden();
    virtual void output();
};
class CFile:public CItem {
protected:
    bool readOnly=false;
public:
    CFile();
    CFile(string Name,int Size);
};
class CFolder: public CItem {
private:
    vector<CItem*>s;
public:
    CFolder();
    
    CFolder(string Name);
    void add(CItem* item);
    void print(bool hidden);
};

#endif /* Function_hpp */
