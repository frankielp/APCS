//
//  Function.cpp
//  Assignment01
//
//  Created by Le Pham Nhat Quynh on 11/23/21.
//

#include "Function.h"
//template<class T>
//MyVector<T>::MyVector(){
//    arr= nullptr;
//    size=0;
//}
//// n zeros
//template<class T>
//MyVector<T>::MyVector(int n){
//    arr=new int [n];
//    for (int i=0;i<n;i++)
//        arr[i]=0;
//    size=n;
//}
//template<class T>
//MyVector<T>::MyVector(T *a, int n){
//    arr=new T [n];
//    size=n;
//}
//template<class T>
//MyVector<T>::MyVector(const MyVector &v){
//    arr=new T [v.size];
//    for (int i=0;i<v.size;i++)
//        arr[i]=v.arr[i];
//    size=v.size;
//}
//template<class T>
//MyVector<T>::~MyVector(){
//    delete [] arr;
//    arr=nullptr;
//    size=0;
//}
//template<class T>
//int MyVector<T>::getSize(){
//    return size;
//}
//template<class T>
//T MyVector<T>::getItem(int index){
//    return arr[index];
//}
//template<class T>
//void MyVector<T>::setItem(T value, int index){
//    arr[index]=value;
//}
//template<class T>
//void MyVector<T>::add(T value){
//    T*tmp=arr;
//    size+=1;
//    arr=new T [size];
//    for (int i=0;i<size-1;i++)
//        arr[i]=tmp[i];
//    arr[size-1]=value;
//    delete[] tmp;
//    tmp=nullptr;
//}
//template<class T>
//void MyVector<T>::addRange(T *a, int n){
//    T*tmp=arr;
//    int m=size;
//    size+=n;
//    arr=new T [size];
//    for (int i=0;i<size-n;i++)
//        arr[i]=tmp[i];
//    for (int i=size-n;i<size;i++)
//        arr[i]=a[i-m];
//    delete[] tmp;
//    tmp=nullptr;
//}
//template<class T>
//void MyVector<T>::clear(){
//    for (int i=0;i<size;i++)
//        arr[i]=0;
//}
//template<class T>
//void MyVector<T>::print(){
//    for (int i=0;i<size;i++)
//        cout<<arr[i]<<endl;
//}
