//
//  main.cpp
//  Assignment01
//
//  Created by Le Pham Nhat Quynh on 11/23/21.
//

#include "Function.h"

int main() {
    
    MyVector<int> a(5);
    a.print();
    
    return 0;
}
