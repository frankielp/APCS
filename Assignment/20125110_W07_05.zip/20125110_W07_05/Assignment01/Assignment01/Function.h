//
//  Function.hpp
//  Assignment01
//
//  Created by Le Pham Nhat Quynh on 11/23/21.
//

#ifndef Function_h
#define Function_h

#include <iostream>
using namespace std;
template<class T>
class MyVector {
private:
    T *arr;
    int size;
public:
    // empty array
    MyVector();
    // n zeros
    MyVector(int n);
    MyVector(T *a, int n);
    MyVector(const MyVector &v);
    ~MyVector();
    int getSize();
    T getItem(int index);
    void setItem(T value, int index);
    void add(T value);
    void addRange(T *a, int n);
    void clear();
//    bool contains(T value);
//    void toArray(T *arr, int &n);
//    bool equals(const MyVector &v);
//    int indexOf(T value);
//    int lastIndexOf(T value);
//    void insert(T value, int index);
//    void remove(T value);
//    void removeAt(int index);
//    void reverse();
//    string toString();
//    void sortAsc();
//    void sortDesc();
    void print();
};
template<class T>
MyVector<T>::MyVector(){
    arr= nullptr;
    size=0;
}
// n zeros
template<class T>
MyVector<T>::MyVector(int n){
    arr=new int [n];
    for (int i=0;i<n;i++)
        arr[i]=0;
    size=n;
}
template<class T>
MyVector<T>::MyVector(T *a, int n){
    arr=new T [n];
    size=n;
}
template<class T>
MyVector<T>::MyVector(const MyVector &v){
    arr=new T [v.size];
    for (int i=0;i<v.size;i++)
        arr[i]=v.arr[i];
    size=v.size;
}
template<class T>
MyVector<T>::~MyVector(){
    delete [] arr;
    arr=nullptr;
    size=0;
}
template<class T>
int MyVector<T>::getSize(){
    return size;
}
template<class T>
T MyVector<T>::getItem(int index){
    return arr[index];
}
template<class T>
void MyVector<T>::setItem(T value, int index){
    arr[index]=value;
}
template<class T>
void MyVector<T>::add(T value){
    T*tmp=arr;
    size+=1;
    arr=new T [size];
    for (int i=0;i<size-1;i++)
        arr[i]=tmp[i];
    arr[size-1]=value;
    delete[] tmp;
    tmp=nullptr;
}
template<class T>
void MyVector<T>::addRange(T *a, int n){
    T*tmp=arr;
    int m=size;
    size+=n;
    arr=new T [size];
    for (int i=0;i<size-n;i++)
        arr[i]=tmp[i];
    for (int i=size-n;i<size;i++)
        arr[i]=a[i-m];
    delete[] tmp;
    tmp=nullptr;
}
template<class T>
void MyVector<T>::clear(){
    for (int i=0;i<size;i++)
        arr[i]=0;
}
template<class T>
void MyVector<T>::print(){
    for (int i=0;i<size;i++)
        cout<<arr[i]<<endl;
}

#endif /* Function_hpp */
