//
//  main.cpp
//  Assignment01
//
//  Created by Le Pham Nhat Quynh on 11/2/21.
//

#include "Function.h"

int main() {
    Worker w1(2012);
    return 0;
}
