//
//  Function.hpp
//  Assignment01
//
//  Created by Le Pham Nhat Quynh on 10/12/21.
//

#ifndef Function_h
#define Function_h

#include <iostream>
using namespace std;
int gcd(int a, int b);
class Fraction{
private:
    int numerator,denominator;
public:
    Fraction()
        {
            numerator = 1;
            denominator = 1;
        }
    
    Fraction(int num,int dem)
    {
            numerator=num;
            denominator=dem;
    }
    void Input()//Input
    {
        int n,d;
        cout<<"Type numerator"<<endl;
        cin>>n;
        cout<<"Type denominator"<<endl;
        cin>>d;
        if (d!=0)
        {
            numerator=n;
            denominator=d;
        }
        else cout<<"Invalid fraction\n";
    }
    void Output() // Output
    {
        if (denominator == 1) // e.g. fraction 2/1 will display simply as 2
            cout << "Fraction = "<<numerator << endl;
        else
            cout << "Fraction = "<<numerator << "/" << denominator << endl;
    }
    Fraction Sum(Fraction frac)
    {
        int n = numerator*frac.denominator+frac.numerator*denominator;
        int d = denominator*frac.denominator;
        return Fraction(n/gcd(n,d),d/gcd(n,d));
    }
    Fraction Subtract(Fraction frac)
    {
        int n = numerator*frac.denominator-frac.numerator*denominator;
        int d = denominator*frac.denominator;
        return Fraction(n/gcd(n,d),d/gcd(n,d));
    }
    Fraction Multiply(Fraction frac)
    {
        int n = numerator*frac.numerator;
        int d = denominator*frac.denominator;
        return Fraction(n/gcd(n,d),d/gcd(n,d));
    }
    Fraction Divide(Fraction frac)
    {
        if (frac.denominator==0)
        {
            cout<<"Invalid operation"<<endl;
            return Fraction(numerator,denominator); //return original Fraction
        }
        int n = numerator*frac.denominator;
        int d = denominator*frac.numerator;
        return Fraction(n/gcd(n,d),d/gcd(n,d));
    }
    Fraction Reduce()
    {
        int n = numerator;
        int d = denominator;
        return Fraction(n/gcd(n,d),d/gcd(n,d));
    }
    int Compare(Fraction frac)
    {
        int diff = numerator*frac.denominator-frac.numerator*denominator;
        if (diff>0) return 1;
        else if (diff==0) return 0;
        else return -1;
    }
    bool isPositive()
    {
        return (numerator>0&&denominator>0)||(numerator<0&&denominator<0);
    }
    bool isNegative()
    {
        return (numerator<0&&denominator>0)||(numerator>0&&denominator<0);
    }
    bool isZero()
    {
        return (numerator==0&&denominator!=0);
    }
};
#endif /* Function_hpp */
