//
//  main.cpp
//  Assignment01
//
//  Created by Le Pham Nhat Quynh on 10/12/21.
//

#include "Function.h"

int main() {
    Fraction a(1,2);
    Fraction b(4,16);
    Fraction d;
    Fraction e(0,5);
    Fraction c;
    cout<<"Fraction d \n";
    d.Input();
    d.Output();
    cout<<"a+b= ";
    c = a.Sum(b);
    cout<<"a-b= ";
    c = a.Subtract(b);
    c.Output();
    cout<<"axb= ";
    c = a.Multiply(b);
    c.Output();
    cout<<"a/b= ";
    c = a.Divide(b);
    c.Output();
    cout<<"Reduced b = ";
    c= b.Reduce();
    c.Output();
    cout<<"Compare a and b : "<<a.Compare(b)<<endl;
    cout<<"e is ";
    if (e.isZero()) cout<<"Zero\n";
    else cout<<"Not zero\n";
    cout<<"b is ";
    if (b.isPositive()) cout<<"Positive\n";
    else cout<<"Not positive\n";
    cout<<"d is ";
    if (d.isNegative()) cout<<"Negative\n";
    else cout<<"Not negative\n";
    return 0;
}
